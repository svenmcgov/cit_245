// Stephen McGovern CIT-245
// 3/8/17

class g{

	public:
		void hello();
		
};
