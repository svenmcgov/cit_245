// Stephen McGovern CIT-245
// 3/8/17

#include "f.h"
#include "g.h"

int main(){
	
	f f1;
	g g1;
	
	f1.hello();
	g1.hello();
	return 0;
}
