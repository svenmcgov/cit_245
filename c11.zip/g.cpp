// Stephen McGovern CIT-245
// 3/8/17

#include <iostream>
using namespace std;
#include "g.h"

void g::hello(){
	cout << "hello from g" << endl;
}
