// Stephen McGovern CIT-245
// 3/8/17

#include <iostream>
using namespace std;
#include "f.h"

void f::hello(){
	cout << "hello from f" << endl;
}
